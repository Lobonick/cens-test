# -*- encoding: utf-8 -*-

ACCION = [
	('manual', 'Manual'), 
	('notificar_correo', 'Notificar por correo'), 
	('notificar_cliente', 'Notificar a cliente'),
]

IMPUESTO = {
	'gratuito': '9996',
	'ICBPER': '7152',
	'igv': '1000',
	'isc': '2000',
	'inafecto': '9998',
	'exonerado': '9997',
	'exportacion': '9995',
}