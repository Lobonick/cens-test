# 10/09/2022
* El monto de retencion se cambia a 2 decimales

# 12/09/2022
* Se actualiza para que el monto en dolares para detracciones no sea redondeado, mas el monto en soles si

# 16/10/2022
* Se carga el modulo como primera version para odoo16

# 20/12/2022
* Se modifica la forma en cofigurar la secuencia de facturas

# 06/12/2023
* Se soluciona bug al emitir un primero comprobante con una nueva serie creada desde la actualización anterior