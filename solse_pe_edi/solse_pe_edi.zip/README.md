# Referencias con e
l10n_pe_edi_refund_reason :: pe_credit_note_code
l10n_pe_edi_charge_reason :: pe_debit_note_code
l10n_pe_edi_cancel_reason :: ahi que crear por que por ahora se ingresa fijo como "Anulado"
l10n_pe_edi_operation_type :: pe_sunat_transaction51
l10n_pe_edi_legend :: 