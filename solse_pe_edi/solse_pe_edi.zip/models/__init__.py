# -*- coding: utf-8 -*-

from . import account_tax
from . import res_company_conf
from . import res_company
from . import l10n_latam_document_type
from . import account_move
from . import account_move_serie
from . import account_move_line
from . import res_partner
from . import res_currency
from . import product